﻿
namespace desainPFN
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnlKiri = new System.Windows.Forms.Panel();
            this.pnlbtn = new System.Windows.Forms.Panel();
            this.pnlMenuMakanan = new System.Windows.Forms.Panel();
            this.tambahmkn = new System.Windows.Forms.Button();
            this.gpSayuran = new System.Windows.Forms.GroupBox();
            this.cap = new System.Windows.Forms.TextBox();
            this.n4 = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.t4 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.gpSeafood = new System.Windows.Forms.GroupBox();
            this.udg = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.t3 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.n3 = new System.Windows.Forms.NumericUpDown();
            this.gpSup = new System.Windows.Forms.GroupBox();
            this.sup = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.t2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.n2 = new System.Windows.Forms.NumericUpDown();
            this.gbAyam = new System.Windows.Forms.GroupBox();
            this.ayam = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.n1 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.t1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pnlMenuMinuman = new System.Windows.Forms.Panel();
            this.tambahmnm = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.doger = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.n8 = new System.Windows.Forms.NumericUpDown();
            this.label36 = new System.Windows.Forms.Label();
            this.t8 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.kopi = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.n7 = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.t7 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.klamud = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.n6 = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.t6 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.teh = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.n5 = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.t5 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.pnlMenuPemesanan = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.cbmeja = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.ttlmnm = new System.Windows.Forms.TextBox();
            this.btnPesan = new System.Windows.Forms.Button();
            this.ttlmkn = new System.Windows.Forms.TextBox();
            this.nama_pmsn = new System.Windows.Forms.TextBox();
            this.totalsemua = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.pnlMenuTentang = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.kembalian = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.bayar = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnTentang = new System.Windows.Forms.Button();
            this.btnPesanan = new System.Windows.Forms.Button();
            this.btnMinuman = new System.Windows.Forms.Button();
            this.btnMakanan = new System.Windows.Forms.Button();
            this.pnlKiri.SuspendLayout();
            this.pnlMenuMakanan.SuspendLayout();
            this.gpSayuran.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n4)).BeginInit();
            this.gpSeafood.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n3)).BeginInit();
            this.gpSup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n2)).BeginInit();
            this.gbAyam.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n1)).BeginInit();
            this.pnlMenuMinuman.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n8)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n7)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n6)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n5)).BeginInit();
            this.pnlMenuPemesanan.SuspendLayout();
            this.pnlMenuTentang.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlKiri
            // 
            this.pnlKiri.BackColor = System.Drawing.Color.Indigo;
            this.pnlKiri.Controls.Add(this.pnlbtn);
            this.pnlKiri.Controls.Add(this.btnTentang);
            this.pnlKiri.Controls.Add(this.btnPesanan);
            this.pnlKiri.Controls.Add(this.btnMinuman);
            this.pnlKiri.Controls.Add(this.btnMakanan);
            this.pnlKiri.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlKiri.Location = new System.Drawing.Point(0, 0);
            this.pnlKiri.Name = "pnlKiri";
            this.pnlKiri.Size = new System.Drawing.Size(195, 678);
            this.pnlKiri.TabIndex = 1;
            this.pnlKiri.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlKiri_Paint);
            // 
            // pnlbtn
            // 
            this.pnlbtn.BackColor = System.Drawing.Color.Yellow;
            this.pnlbtn.Location = new System.Drawing.Point(0, 134);
            this.pnlbtn.Name = "pnlbtn";
            this.pnlbtn.Size = new System.Drawing.Size(9, 85);
            this.pnlbtn.TabIndex = 10;
            // 
            // pnlMenuMakanan
            // 
            this.pnlMenuMakanan.Controls.Add(this.tambahmkn);
            this.pnlMenuMakanan.Controls.Add(this.gpSayuran);
            this.pnlMenuMakanan.Controls.Add(this.gpSeafood);
            this.pnlMenuMakanan.Controls.Add(this.gpSup);
            this.pnlMenuMakanan.Controls.Add(this.gbAyam);
            this.pnlMenuMakanan.Controls.Add(this.label7);
            this.pnlMenuMakanan.Location = new System.Drawing.Point(200, -2);
            this.pnlMenuMakanan.Name = "pnlMenuMakanan";
            this.pnlMenuMakanan.Size = new System.Drawing.Size(837, 683);
            this.pnlMenuMakanan.TabIndex = 18;
            this.pnlMenuMakanan.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMenuMakanan_Paint);
            // 
            // tambahmkn
            // 
            this.tambahmkn.BackColor = System.Drawing.Color.Lime;
            this.tambahmkn.Location = new System.Drawing.Point(597, 588);
            this.tambahmkn.Name = "tambahmkn";
            this.tambahmkn.Size = new System.Drawing.Size(201, 49);
            this.tambahmkn.TabIndex = 23;
            this.tambahmkn.Text = "Tambah";
            this.tambahmkn.UseVisualStyleBackColor = false;
            this.tambahmkn.Click += new System.EventHandler(this.button1_Click);
            // 
            // gpSayuran
            // 
            this.gpSayuran.BackColor = System.Drawing.Color.Indigo;
            this.gpSayuran.Controls.Add(this.cap);
            this.gpSayuran.Controls.Add(this.n4);
            this.gpSayuran.Controls.Add(this.label16);
            this.gpSayuran.Controls.Add(this.label14);
            this.gpSayuran.Controls.Add(this.panel4);
            this.gpSayuran.Controls.Add(this.t4);
            this.gpSayuran.Controls.Add(this.label27);
            this.gpSayuran.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpSayuran.ForeColor = System.Drawing.Color.White;
            this.gpSayuran.Location = new System.Drawing.Point(435, 348);
            this.gpSayuran.Name = "gpSayuran";
            this.gpSayuran.Size = new System.Drawing.Size(363, 234);
            this.gpSayuran.TabIndex = 22;
            this.gpSayuran.TabStop = false;
            this.gpSayuran.Text = "Capcay";
            // 
            // cap
            // 
            this.cap.Enabled = false;
            this.cap.Location = new System.Drawing.Point(243, 64);
            this.cap.Name = "cap";
            this.cap.Size = new System.Drawing.Size(74, 31);
            this.cap.TabIndex = 27;
            this.cap.Text = "16000";
            this.cap.TextChanged += new System.EventHandler(this.cap_TextChanged);
            // 
            // n4
            // 
            this.n4.Location = new System.Drawing.Point(168, 147);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(63, 31);
            this.n4.TabIndex = 14;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(-3, 155);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(159, 24);
            this.label16.TabIndex = 26;
            this.label16.Text = "Banyak Pesanan";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(246, 37);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 24);
            this.label14.TabIndex = 26;
            this.label14.Text = "Harga";
            // 
            // t4
            // 
            this.t4.Enabled = false;
            this.t4.Location = new System.Drawing.Point(168, 188);
            this.t4.Name = "t4";
            this.t4.ReadOnly = true;
            this.t4.Size = new System.Drawing.Size(174, 31);
            this.t4.TabIndex = 20;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(98, 195);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(59, 24);
            this.label27.TabIndex = 19;
            this.label27.Text = "Total";
            // 
            // gpSeafood
            // 
            this.gpSeafood.BackColor = System.Drawing.Color.Indigo;
            this.gpSeafood.Controls.Add(this.udg);
            this.gpSeafood.Controls.Add(this.label13);
            this.gpSeafood.Controls.Add(this.label8);
            this.gpSeafood.Controls.Add(this.panel3);
            this.gpSeafood.Controls.Add(this.t3);
            this.gpSeafood.Controls.Add(this.label12);
            this.gpSeafood.Controls.Add(this.n3);
            this.gpSeafood.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpSeafood.ForeColor = System.Drawing.Color.White;
            this.gpSeafood.Location = new System.Drawing.Point(42, 349);
            this.gpSeafood.Name = "gpSeafood";
            this.gpSeafood.Size = new System.Drawing.Size(366, 234);
            this.gpSeafood.TabIndex = 21;
            this.gpSeafood.TabStop = false;
            this.gpSeafood.Text = "Udang Goreng";
            // 
            // udg
            // 
            this.udg.Enabled = false;
            this.udg.Location = new System.Drawing.Point(246, 55);
            this.udg.Name = "udg";
            this.udg.Size = new System.Drawing.Size(74, 31);
            this.udg.TabIndex = 27;
            this.udg.Text = "12000";
            this.udg.TextChanged += new System.EventHandler(this.udg_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 154);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(159, 24);
            this.label13.TabIndex = 25;
            this.label13.Text = "Banyak Pesanan";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(248, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 24);
            this.label8.TabIndex = 25;
            this.label8.Text = "Harga";
            // 
            // t3
            // 
            this.t3.Enabled = false;
            this.t3.Location = new System.Drawing.Point(172, 189);
            this.t3.Name = "t3";
            this.t3.ReadOnly = true;
            this.t3.Size = new System.Drawing.Size(180, 31);
            this.t3.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(99, 194);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 24);
            this.label12.TabIndex = 19;
            this.label12.Text = "Total";
            // 
            // n3
            // 
            this.n3.Location = new System.Drawing.Point(172, 151);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(63, 31);
            this.n3.TabIndex = 14;
            // 
            // gpSup
            // 
            this.gpSup.BackColor = System.Drawing.Color.Indigo;
            this.gpSup.Controls.Add(this.sup);
            this.gpSup.Controls.Add(this.label6);
            this.gpSup.Controls.Add(this.label1);
            this.gpSup.Controls.Add(this.panel2);
            this.gpSup.Controls.Add(this.t2);
            this.gpSup.Controls.Add(this.label11);
            this.gpSup.Controls.Add(this.n2);
            this.gpSup.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpSup.ForeColor = System.Drawing.Color.White;
            this.gpSup.Location = new System.Drawing.Point(435, 92);
            this.gpSup.Name = "gpSup";
            this.gpSup.Size = new System.Drawing.Size(363, 234);
            this.gpSup.TabIndex = 15;
            this.gpSup.TabStop = false;
            this.gpSup.Text = "Sup Kambing";
            // 
            // sup
            // 
            this.sup.Enabled = false;
            this.sup.Location = new System.Drawing.Point(243, 76);
            this.sup.Name = "sup";
            this.sup.Size = new System.Drawing.Size(74, 31);
            this.sup.TabIndex = 26;
            this.sup.Text = "38000";
            this.sup.TextChanged += new System.EventHandler(this.sup_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(10, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(159, 24);
            this.label6.TabIndex = 25;
            this.label6.Text = "Banyak Pesanan";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(246, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 24);
            this.label1.TabIndex = 25;
            this.label1.Text = "Harga";
            // 
            // t2
            // 
            this.t2.Enabled = false;
            this.t2.Location = new System.Drawing.Point(177, 183);
            this.t2.Name = "t2";
            this.t2.ReadOnly = true;
            this.t2.Size = new System.Drawing.Size(164, 31);
            this.t2.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(106, 189);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 24);
            this.label11.TabIndex = 20;
            this.label11.Text = "Total";
            // 
            // n2
            // 
            this.n2.Location = new System.Drawing.Point(177, 145);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(63, 31);
            this.n2.TabIndex = 14;
            // 
            // gbAyam
            // 
            this.gbAyam.BackColor = System.Drawing.Color.Indigo;
            this.gbAyam.Controls.Add(this.ayam);
            this.gbAyam.Controls.Add(this.label4);
            this.gbAyam.Controls.Add(this.n1);
            this.gbAyam.Controls.Add(this.label2);
            this.gbAyam.Controls.Add(this.panel1);
            this.gbAyam.Controls.Add(this.t1);
            this.gbAyam.Controls.Add(this.label10);
            this.gbAyam.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbAyam.ForeColor = System.Drawing.Color.White;
            this.gbAyam.Location = new System.Drawing.Point(42, 92);
            this.gbAyam.Name = "gbAyam";
            this.gbAyam.Size = new System.Drawing.Size(366, 234);
            this.gbAyam.TabIndex = 8;
            this.gbAyam.TabStop = false;
            this.gbAyam.Text = "Ayam Bakar";
            // 
            // ayam
            // 
            this.ayam.Enabled = false;
            this.ayam.Location = new System.Drawing.Point(252, 76);
            this.ayam.Name = "ayam";
            this.ayam.Size = new System.Drawing.Size(74, 31);
            this.ayam.TabIndex = 25;
            this.ayam.Text = "30000";
            this.ayam.TextChanged += new System.EventHandler(this.ayam_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(2, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 24);
            this.label4.TabIndex = 24;
            this.label4.Text = "Banyak Pesanan";
            // 
            // n1
            // 
            this.n1.Location = new System.Drawing.Point(176, 146);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(63, 31);
            this.n1.TabIndex = 23;
            this.n1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(254, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 24);
            this.label2.TabIndex = 22;
            this.label2.Text = "Harga";
            // 
            // t1
            // 
            this.t1.Enabled = false;
            this.t1.Location = new System.Drawing.Point(174, 185);
            this.t1.Name = "t1";
            this.t1.ReadOnly = true;
            this.t1.Size = new System.Drawing.Size(178, 31);
            this.t1.TabIndex = 20;
            this.t1.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(99, 189);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 24);
            this.label10.TabIndex = 19;
            this.label10.Text = "Total";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Papyrus", 24F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(225, -2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(375, 76);
            this.label7.TabIndex = 1;
            this.label7.Text = "Menu Makanan";
            // 
            // pnlMenuMinuman
            // 
            this.pnlMenuMinuman.Controls.Add(this.tambahmnm);
            this.pnlMenuMinuman.Controls.Add(this.groupBox4);
            this.pnlMenuMinuman.Controls.Add(this.groupBox3);
            this.pnlMenuMinuman.Controls.Add(this.groupBox2);
            this.pnlMenuMinuman.Controls.Add(this.groupBox1);
            this.pnlMenuMinuman.Controls.Add(this.label42);
            this.pnlMenuMinuman.Location = new System.Drawing.Point(200, -3);
            this.pnlMenuMinuman.Name = "pnlMenuMinuman";
            this.pnlMenuMinuman.Size = new System.Drawing.Size(840, 695);
            this.pnlMenuMinuman.TabIndex = 25;
            // 
            // tambahmnm
            // 
            this.tambahmnm.BackColor = System.Drawing.Color.Lime;
            this.tambahmnm.Location = new System.Drawing.Point(597, 591);
            this.tambahmnm.Name = "tambahmnm";
            this.tambahmnm.Size = new System.Drawing.Size(201, 49);
            this.tambahmnm.TabIndex = 29;
            this.tambahmnm.Text = "Tambah";
            this.tambahmnm.UseVisualStyleBackColor = false;
            this.tambahmnm.Click += new System.EventHandler(this.tambahmnm_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Indigo;
            this.groupBox4.Controls.Add(this.doger);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.n8);
            this.groupBox4.Controls.Add(this.label36);
            this.groupBox4.Controls.Add(this.panel8);
            this.groupBox4.Controls.Add(this.t8);
            this.groupBox4.Controls.Add(this.label37);
            this.groupBox4.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(432, 351);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(366, 234);
            this.groupBox4.TabIndex = 26;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Es Doger";
            // 
            // doger
            // 
            this.doger.Enabled = false;
            this.doger.Location = new System.Drawing.Point(259, 72);
            this.doger.Name = "doger";
            this.doger.Size = new System.Drawing.Size(61, 31);
            this.doger.TabIndex = 28;
            this.doger.Text = "10000";
            this.doger.TextChanged += new System.EventHandler(this.doger_TextChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(2, 152);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(159, 24);
            this.label34.TabIndex = 24;
            this.label34.Text = "Banyak Pesanan";
            // 
            // n8
            // 
            this.n8.Location = new System.Drawing.Point(176, 146);
            this.n8.Name = "n8";
            this.n8.Size = new System.Drawing.Size(63, 31);
            this.n8.TabIndex = 23;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(254, 46);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(66, 24);
            this.label36.TabIndex = 22;
            this.label36.Text = "Harga";
            // 
            // t8
            // 
            this.t8.Enabled = false;
            this.t8.Location = new System.Drawing.Point(174, 185);
            this.t8.Name = "t8";
            this.t8.ReadOnly = true;
            this.t8.Size = new System.Drawing.Size(178, 31);
            this.t8.TabIndex = 20;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(99, 189);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(59, 24);
            this.label37.TabIndex = 19;
            this.label37.Text = "Total";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Indigo;
            this.groupBox3.Controls.Add(this.kopi);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.n7);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.panel7);
            this.groupBox3.Controls.Add(this.t7);
            this.groupBox3.Controls.Add(this.label33);
            this.groupBox3.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(42, 351);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(366, 234);
            this.groupBox3.TabIndex = 25;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Kopi";
            // 
            // kopi
            // 
            this.kopi.Enabled = false;
            this.kopi.Location = new System.Drawing.Point(258, 73);
            this.kopi.Name = "kopi";
            this.kopi.Size = new System.Drawing.Size(61, 31);
            this.kopi.TabIndex = 27;
            this.kopi.Text = "6000";
            this.kopi.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(2, 152);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(159, 24);
            this.label30.TabIndex = 24;
            this.label30.Text = "Banyak Pesanan";
            // 
            // n7
            // 
            this.n7.Location = new System.Drawing.Point(176, 146);
            this.n7.Name = "n7";
            this.n7.Size = new System.Drawing.Size(63, 31);
            this.n7.TabIndex = 23;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(254, 46);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(66, 24);
            this.label32.TabIndex = 22;
            this.label32.Text = "Harga";
            // 
            // t7
            // 
            this.t7.Enabled = false;
            this.t7.Location = new System.Drawing.Point(174, 185);
            this.t7.Name = "t7";
            this.t7.ReadOnly = true;
            this.t7.Size = new System.Drawing.Size(178, 31);
            this.t7.TabIndex = 20;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(99, 189);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(59, 24);
            this.label33.TabIndex = 19;
            this.label33.Text = "Total";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Indigo;
            this.groupBox2.Controls.Add(this.klamud);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.n6);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.panel6);
            this.groupBox2.Controls.Add(this.t6);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(432, 94);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(366, 234);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kelapa Muda";
            // 
            // klamud
            // 
            this.klamud.Enabled = false;
            this.klamud.Location = new System.Drawing.Point(258, 73);
            this.klamud.Name = "klamud";
            this.klamud.Size = new System.Drawing.Size(61, 31);
            this.klamud.TabIndex = 26;
            this.klamud.Text = "8000";
            this.klamud.TextChanged += new System.EventHandler(this.klamud_TextChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(2, 152);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(159, 24);
            this.label22.TabIndex = 24;
            this.label22.Text = "Banyak Pesanan";
            // 
            // n6
            // 
            this.n6.Location = new System.Drawing.Point(176, 146);
            this.n6.Name = "n6";
            this.n6.Size = new System.Drawing.Size(63, 31);
            this.n6.TabIndex = 23;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(254, 46);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 24);
            this.label24.TabIndex = 22;
            this.label24.Text = "Harga";
            // 
            // t6
            // 
            this.t6.Enabled = false;
            this.t6.Location = new System.Drawing.Point(174, 185);
            this.t6.Name = "t6";
            this.t6.ReadOnly = true;
            this.t6.Size = new System.Drawing.Size(178, 31);
            this.t6.TabIndex = 20;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(99, 189);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(59, 24);
            this.label25.TabIndex = 19;
            this.label25.Text = "Total";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Indigo;
            this.groupBox1.Controls.Add(this.teh);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.n5);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.panel5);
            this.groupBox1.Controls.Add(this.t5);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(42, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(366, 234);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Es Teh";
            // 
            // teh
            // 
            this.teh.Enabled = false;
            this.teh.Location = new System.Drawing.Point(259, 75);
            this.teh.Name = "teh";
            this.teh.Size = new System.Drawing.Size(61, 31);
            this.teh.TabIndex = 25;
            this.teh.Text = "5000";
            this.teh.TextChanged += new System.EventHandler(this.teh_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(2, 152);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(159, 24);
            this.label17.TabIndex = 24;
            this.label17.Text = "Banyak Pesanan";
            // 
            // n5
            // 
            this.n5.Location = new System.Drawing.Point(176, 146);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(63, 31);
            this.n5.TabIndex = 23;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(254, 46);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(66, 24);
            this.label28.TabIndex = 22;
            this.label28.Text = "Harga";
            // 
            // t5
            // 
            this.t5.Enabled = false;
            this.t5.Location = new System.Drawing.Point(174, 185);
            this.t5.Name = "t5";
            this.t5.ReadOnly = true;
            this.t5.Size = new System.Drawing.Size(178, 31);
            this.t5.TabIndex = 20;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Baskerville Old Face", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(99, 189);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 24);
            this.label29.TabIndex = 19;
            this.label29.Text = "Total";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Papyrus", 24F, System.Drawing.FontStyle.Bold);
            this.label42.Location = new System.Drawing.Point(240, -3);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(368, 76);
            this.label42.TabIndex = 1;
            this.label42.Text = "Menu Minuman";
            // 
            // pnlMenuPemesanan
            // 
            this.pnlMenuPemesanan.Controls.Add(this.bayar);
            this.pnlMenuPemesanan.Controls.Add(this.label5);
            this.pnlMenuPemesanan.Controls.Add(this.kembalian);
            this.pnlMenuPemesanan.Controls.Add(this.label3);
            this.pnlMenuPemesanan.Controls.Add(this.button1);
            this.pnlMenuPemesanan.Controls.Add(this.cbmeja);
            this.pnlMenuPemesanan.Controls.Add(this.label20);
            this.pnlMenuPemesanan.Controls.Add(this.ttlmnm);
            this.pnlMenuPemesanan.Controls.Add(this.btnPesan);
            this.pnlMenuPemesanan.Controls.Add(this.ttlmkn);
            this.pnlMenuPemesanan.Controls.Add(this.nama_pmsn);
            this.pnlMenuPemesanan.Controls.Add(this.totalsemua);
            this.pnlMenuPemesanan.Controls.Add(this.label19);
            this.pnlMenuPemesanan.Controls.Add(this.label18);
            this.pnlMenuPemesanan.Controls.Add(this.label21);
            this.pnlMenuPemesanan.Controls.Add(this.label43);
            this.pnlMenuPemesanan.Controls.Add(this.label46);
            this.pnlMenuPemesanan.Location = new System.Drawing.Point(201, 3);
            this.pnlMenuPemesanan.Name = "pnlMenuPemesanan";
            this.pnlMenuPemesanan.Size = new System.Drawing.Size(837, 678);
            this.pnlMenuPemesanan.TabIndex = 26;
            this.pnlMenuPemesanan.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMenuPemesanan_Paint);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.Location = new System.Drawing.Point(323, 384);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 38);
            this.button1.TabIndex = 20;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // cbmeja
            // 
            this.cbmeja.FormattingEnabled = true;
            this.cbmeja.Location = new System.Drawing.Point(336, 175);
            this.cbmeja.Name = "cbmeja";
            this.cbmeja.Size = new System.Drawing.Size(205, 28);
            this.cbmeja.TabIndex = 19;
            this.cbmeja.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(254, 180);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(64, 23);
            this.label20.TabIndex = 18;
            this.label20.Text = "No Meja";
            // 
            // ttlmnm
            // 
            this.ttlmnm.Location = new System.Drawing.Point(334, 243);
            this.ttlmnm.Name = "ttlmnm";
            this.ttlmnm.ReadOnly = true;
            this.ttlmnm.Size = new System.Drawing.Size(206, 26);
            this.ttlmnm.TabIndex = 14;
            this.ttlmnm.TextChanged += new System.EventHandler(this.ttlmnm_TextChanged);
            // 
            // btnPesan
            // 
            this.btnPesan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnPesan.Location = new System.Drawing.Point(448, 384);
            this.btnPesan.Name = "btnPesan";
            this.btnPesan.Size = new System.Drawing.Size(102, 38);
            this.btnPesan.TabIndex = 15;
            this.btnPesan.Text = "Pesan";
            this.btnPesan.UseVisualStyleBackColor = false;
            this.btnPesan.Click += new System.EventHandler(this.btnPesan_Click);
            // 
            // ttlmkn
            // 
            this.ttlmkn.Location = new System.Drawing.Point(336, 211);
            this.ttlmkn.Name = "ttlmkn";
            this.ttlmkn.ReadOnly = true;
            this.ttlmkn.Size = new System.Drawing.Size(205, 26);
            this.ttlmkn.TabIndex = 13;
            this.ttlmkn.TextChanged += new System.EventHandler(this.ttlmkn_TextChanged);
            // 
            // nama_pmsn
            // 
            this.nama_pmsn.Location = new System.Drawing.Point(334, 143);
            this.nama_pmsn.Name = "nama_pmsn";
            this.nama_pmsn.Size = new System.Drawing.Size(207, 26);
            this.nama_pmsn.TabIndex = 11;
            // 
            // totalsemua
            // 
            this.totalsemua.Location = new System.Drawing.Point(336, 277);
            this.totalsemua.Name = "totalsemua";
            this.totalsemua.ReadOnly = true;
            this.totalsemua.Size = new System.Drawing.Size(204, 26);
            this.totalsemua.TabIndex = 10;
            this.totalsemua.TextChanged += new System.EventHandler(this.totalsemua_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(208, 243);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(114, 23);
            this.label19.TabIndex = 7;
            this.label19.Text = "Harga Minuman";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(210, 209);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(113, 23);
            this.label18.TabIndex = 6;
            this.label18.Text = "Harga Makanan";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(269, 145);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 23);
            this.label21.TabIndex = 4;
            this.label21.Text = "Nama";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(276, 278);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(42, 23);
            this.label43.TabIndex = 3;
            this.label43.Text = "Total";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Papyrus", 24F, System.Drawing.FontStyle.Bold);
            this.label46.Location = new System.Drawing.Point(267, -2);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(273, 76);
            this.label46.TabIndex = 0;
            this.label46.Text = "Pemesanan";
            // 
            // pnlMenuTentang
            // 
            this.pnlMenuTentang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnlMenuTentang.Controls.Add(this.panel9);
            this.pnlMenuTentang.Controls.Add(this.label49);
            this.pnlMenuTentang.Location = new System.Drawing.Point(200, 0);
            this.pnlMenuTentang.Name = "pnlMenuTentang";
            this.pnlMenuTentang.Size = new System.Drawing.Size(837, 682);
            this.pnlMenuTentang.TabIndex = 27;
            this.pnlMenuTentang.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMenuTentang_Paint);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Papyrus", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(202, -2);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(395, 76);
            this.label49.TabIndex = 0;
            this.label49.Text = "Selamat Datang";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(271, 312);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 23);
            this.label3.TabIndex = 21;
            this.label3.Text = "Bayar";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // kembalian
            // 
            this.kembalian.Location = new System.Drawing.Point(337, 345);
            this.kembalian.Name = "kembalian";
            this.kembalian.ReadOnly = true;
            this.kembalian.Size = new System.Drawing.Size(204, 26);
            this.kembalian.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(237, 349);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 23);
            this.label5.TabIndex = 24;
            this.label5.Text = "Kembalian";
            // 
            // bayar
            // 
            this.bayar.Location = new System.Drawing.Point(337, 313);
            this.bayar.Name = "bayar";
            this.bayar.Size = new System.Drawing.Size(207, 26);
            this.bayar.TabIndex = 25;
            this.bayar.TextChanged += new System.EventHandler(this.bayar_TextChanged_1);
            // 
            // panel9
            // 
            this.panel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel9.BackgroundImage")));
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel9.Location = new System.Drawing.Point(174, 134);
            this.panel9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(468, 357);
            this.panel9.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel8.BackgroundImage")));
            this.panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel8.Location = new System.Drawing.Point(18, 25);
            this.panel8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(177, 114);
            this.panel8.TabIndex = 21;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel7.Location = new System.Drawing.Point(18, 23);
            this.panel7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(177, 114);
            this.panel7.TabIndex = 21;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel6.Location = new System.Drawing.Point(-22, 25);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(243, 114);
            this.panel6.TabIndex = 21;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel5.Location = new System.Drawing.Point(18, 25);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(153, 114);
            this.panel5.TabIndex = 21;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel4.Location = new System.Drawing.Point(27, 25);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(170, 123);
            this.panel4.TabIndex = 23;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel3.Location = new System.Drawing.Point(22, 25);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(177, 114);
            this.panel3.TabIndex = 22;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel2.Location = new System.Drawing.Point(15, 25);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(196, 114);
            this.panel2.TabIndex = 22;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(22, 25);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(177, 114);
            this.panel1.TabIndex = 21;
            // 
            // btnTentang
            // 
            this.btnTentang.FlatAppearance.BorderSize = 0;
            this.btnTentang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTentang.Font = new System.Drawing.Font("Franklin Gothic Demi", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTentang.ForeColor = System.Drawing.Color.White;
            this.btnTentang.Image = global::desainPFN.Properties.Resources.Home;
            this.btnTentang.Location = new System.Drawing.Point(0, 134);
            this.btnTentang.Name = "btnTentang";
            this.btnTentang.Size = new System.Drawing.Size(200, 85);
            this.btnTentang.TabIndex = 9;
            this.btnTentang.Text = "       Beranda";
            this.btnTentang.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTentang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTentang.UseVisualStyleBackColor = true;
            this.btnTentang.Click += new System.EventHandler(this.btnTentang_Click);
            // 
            // btnPesanan
            // 
            this.btnPesanan.FlatAppearance.BorderSize = 0;
            this.btnPesanan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesanan.Font = new System.Drawing.Font("Franklin Gothic Demi", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPesanan.ForeColor = System.Drawing.Color.White;
            this.btnPesanan.Image = global::desainPFN.Properties.Resources.pesanan;
            this.btnPesanan.Location = new System.Drawing.Point(-2, 405);
            this.btnPesanan.Name = "btnPesanan";
            this.btnPesanan.Size = new System.Drawing.Size(198, 85);
            this.btnPesanan.TabIndex = 7;
            this.btnPesanan.Text = "   Pemesanan";
            this.btnPesanan.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPesanan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPesanan.UseVisualStyleBackColor = true;
            this.btnPesanan.Click += new System.EventHandler(this.btnPesanan_Click);
            // 
            // btnMinuman
            // 
            this.btnMinuman.FlatAppearance.BorderSize = 0;
            this.btnMinuman.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinuman.Font = new System.Drawing.Font("Franklin Gothic Demi", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinuman.ForeColor = System.Drawing.Color.White;
            this.btnMinuman.Image = global::desainPFN.Properties.Resources.drink;
            this.btnMinuman.Location = new System.Drawing.Point(-2, 315);
            this.btnMinuman.Name = "btnMinuman";
            this.btnMinuman.Size = new System.Drawing.Size(198, 85);
            this.btnMinuman.TabIndex = 5;
            this.btnMinuman.Text = "      Minuman";
            this.btnMinuman.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMinuman.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMinuman.UseVisualStyleBackColor = true;
            this.btnMinuman.Click += new System.EventHandler(this.btnMinuman_Click);
            // 
            // btnMakanan
            // 
            this.btnMakanan.FlatAppearance.BorderSize = 0;
            this.btnMakanan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMakanan.Font = new System.Drawing.Font("Franklin Gothic Demi", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMakanan.ForeColor = System.Drawing.Color.White;
            this.btnMakanan.Image = global::desainPFN.Properties.Resources.food;
            this.btnMakanan.Location = new System.Drawing.Point(0, 226);
            this.btnMakanan.Name = "btnMakanan";
            this.btnMakanan.Size = new System.Drawing.Size(198, 85);
            this.btnMakanan.TabIndex = 3;
            this.btnMakanan.Text = "      Makanan";
            this.btnMakanan.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMakanan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMakanan.UseVisualStyleBackColor = true;
            this.btnMakanan.Click += new System.EventHandler(this.btnMakanan_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 678);
            this.Controls.Add(this.pnlMenuTentang);
            this.Controls.Add(this.pnlMenuMinuman);
            this.Controls.Add(this.pnlMenuMakanan);
            this.Controls.Add(this.pnlMenuPemesanan);
            this.Controls.Add(this.pnlKiri);
            this.Name = "Form1";
            this.Text = "MENU";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlKiri.ResumeLayout(false);
            this.pnlMenuMakanan.ResumeLayout(false);
            this.pnlMenuMakanan.PerformLayout();
            this.gpSayuran.ResumeLayout(false);
            this.gpSayuran.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n4)).EndInit();
            this.gpSeafood.ResumeLayout(false);
            this.gpSeafood.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n3)).EndInit();
            this.gpSup.ResumeLayout(false);
            this.gpSup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n2)).EndInit();
            this.gbAyam.ResumeLayout(false);
            this.gbAyam.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n1)).EndInit();
            this.pnlMenuMinuman.ResumeLayout(false);
            this.pnlMenuMinuman.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n8)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n7)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n6)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n5)).EndInit();
            this.pnlMenuPemesanan.ResumeLayout(false);
            this.pnlMenuPemesanan.PerformLayout();
            this.pnlMenuTentang.ResumeLayout(false);
            this.pnlMenuTentang.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlKiri;
        private System.Windows.Forms.Panel pnlbtn;
        private System.Windows.Forms.Button btnTentang;
        private System.Windows.Forms.Button btnPesanan;
        private System.Windows.Forms.Button btnMinuman;
        private System.Windows.Forms.Button btnMakanan;
        private System.Windows.Forms.Panel pnlMenuMakanan;
        private System.Windows.Forms.GroupBox gpSayuran;
        private System.Windows.Forms.TextBox t4;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown n4;
        private System.Windows.Forms.GroupBox gpSup;
        private System.Windows.Forms.TextBox t2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown n2;
        private System.Windows.Forms.GroupBox gbAyam;
        private System.Windows.Forms.TextBox t1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel pnlMenuMinuman;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel pnlMenuPemesanan;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnPesan;
        private System.Windows.Forms.TextBox ttlmnm;
        private System.Windows.Forms.TextBox ttlmkn;
        private System.Windows.Forms.TextBox nama_pmsn;
        private System.Windows.Forms.TextBox totalsemua;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel pnlMenuTentang;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.ComboBox cbmeja;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox gpSeafood;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox t3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown n3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown n1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown n8;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox t8;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown n7;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox t7;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown n6;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox t6;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown n5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox t5;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox ayam;
        private System.Windows.Forms.Button tambahmkn;
        private System.Windows.Forms.TextBox cap;
        private System.Windows.Forms.TextBox udg;
        private System.Windows.Forms.TextBox sup;
        private System.Windows.Forms.TextBox doger;
        private System.Windows.Forms.TextBox kopi;
        private System.Windows.Forms.TextBox klamud;
        private System.Windows.Forms.TextBox teh;
        private System.Windows.Forms.Button tambahmnm;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox kembalian;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox bayar;
    }
}