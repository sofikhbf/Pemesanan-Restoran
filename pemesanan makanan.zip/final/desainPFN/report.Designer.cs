﻿namespace desainPFN
{
    partial class report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.tbl_transaksiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dbrestoranDataSet = new desainPFN.dbrestoranDataSet();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tbl_transaksiTableAdapter = new desainPFN.dbrestoranDataSetTableAdapters.tbl_transaksiTableAdapter();
            this.dbrestoranDataSet1 = new desainPFN.dbrestoranDataSet1();
            this.tbl_transkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_transkTableAdapter = new desainPFN.dbrestoranDataSet1TableAdapters.tbl_transkTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_transaksiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbrestoranDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbrestoranDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_transkBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tbl_transaksiBindingSource
            // 
            this.tbl_transaksiBindingSource.DataMember = "tbl_transaksi";
            this.tbl_transaksiBindingSource.DataSource = this.dbrestoranDataSet;
            // 
            // dbrestoranDataSet
            // 
            this.dbrestoranDataSet.DataSetName = "dbrestoranDataSet";
            this.dbrestoranDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.tbl_transkBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "desainPFN.Report2.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 12);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(845, 583);
            this.reportViewer1.TabIndex = 0;
            // 
            // tbl_transaksiTableAdapter
            // 
            this.tbl_transaksiTableAdapter.ClearBeforeFill = true;
            // 
            // dbrestoranDataSet1
            // 
            this.dbrestoranDataSet1.DataSetName = "dbrestoranDataSet1";
            this.dbrestoranDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_transkBindingSource
            // 
            this.tbl_transkBindingSource.DataMember = "tbl_transk";
            this.tbl_transkBindingSource.DataSource = this.dbrestoranDataSet1;
            // 
            // tbl_transkTableAdapter
            // 
            this.tbl_transkTableAdapter.ClearBeforeFill = true;
            // 
            // report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(869, 617);
            this.Controls.Add(this.reportViewer1);
            this.Name = "report";
            this.Text = "report";
            this.Load += new System.EventHandler(this.report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tbl_transaksiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbrestoranDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dbrestoranDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_transkBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource tbl_transaksiBindingSource;
        private dbrestoranDataSet dbrestoranDataSet;
        private dbrestoranDataSetTableAdapters.tbl_transaksiTableAdapter tbl_transaksiTableAdapter;
        private System.Windows.Forms.BindingSource tbl_transkBindingSource;
        private dbrestoranDataSet1 dbrestoranDataSet1;
        private dbrestoranDataSet1TableAdapters.tbl_transkTableAdapter tbl_transkTableAdapter;
    }
}