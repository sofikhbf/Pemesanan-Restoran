﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desainPFN
{
    public partial class utama : Form
    {
        public utama()
        {
            InitializeComponent();
        }

        private void admin_Click(object sender, EventArgs e)
        {
            admin tp = new admin();
            tp.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 fr = new Form1();
            fr.Show();
        }
    }
}
