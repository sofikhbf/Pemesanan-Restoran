﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desainPFN
{
    public partial class view : Form
    {
        public view()
        {
            InitializeComponent();
        }

        DataClasses1DataContext dt = new DataClasses1DataContext();

        private void tampilData()
        {
            var tr = from b in dt.tbl_transks select b;
            dgv.DataSource = tr;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void view_Load(object sender, EventArgs e)
        {
            tampilData();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        private void clearData()
        {
            trans.Clear();
            kasir.Clear();
            plyn.Clear();
            pesan.Clear();
            kons.Clear();
            total.Clear();
            trans.Focus();
        }

        private void Tambah_Click(object sender, EventArgs e)
        {
           
            string id_trans = trans.Text, id_kas = kasir.Text, id_plyn = plyn.Text, id_psn = pesan.Text, id_kons = kons.Text, ttl = total.Text;

            var tr = new tbl_transk
            {
                Id_transaksi = id_trans,
                Id_kasir = id_kas,
                Id_pelayan = id_plyn,
                Id_pesanan = id_psn,
                Id_konsumen = id_kons,
                total = ttl
            };
            dt.tbl_transks.InsertOnSubmit(tr);
            dt.SubmitChanges();
            MessageBox.Show("Data Berhasil Ditambahkan!!");
            tampilData();
            clearData();

        }

        private void update_Click(object sender, EventArgs e)
        {
            string id_trans = trans.Text, id_kas = kasir.Text, id_plyn = plyn.Text, id_psn = pesan.Text, id_kons = kons.Text, ttl = total.Text;

            var tr =(from b in dt.tbl_transks where b.Id_transaksi == trans.Text select b).First();

            
                tr.Id_transaksi = id_trans;
                tr.Id_kasir = id_kas;
                tr.Id_pelayan = id_plyn;
                tr.Id_pesanan = id_psn;
                tr.Id_konsumen = id_kons;
                tr.total = ttl;
            
     
            dt.SubmitChanges();
            MessageBox.Show("Data Berhasil DiUpdate");
            tampilData();
            clearData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var tr = (from b in dt.tbl_transks where b.Id_transaksi == trans.Text select b).First();
            dt.tbl_transks.DeleteOnSubmit(tr);
            dt.SubmitChanges();
            MessageBox.Show("Data Berhasil DiHapus!!");
            tampilData();
            clearData();
        }

        private void clear_Click(object sender, EventArgs e)
        {
            clearData();
        }
    }
}
