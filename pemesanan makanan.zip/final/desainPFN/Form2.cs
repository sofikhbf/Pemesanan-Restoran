﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desainPFN
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        
        private void pnlTop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Tampil_Click(object sender, EventArgs e)
        {
            report rp = new report();
            rp.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            view vw = new view();
            vw.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
