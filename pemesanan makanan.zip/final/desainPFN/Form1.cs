﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desainPFN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMakanan_Click(object sender, EventArgs e)
        {
            pnlbtn.Height = btnMakanan.Height;
            pnlbtn.Top = btnMakanan.Top;
            pnlMenuMakanan.Visible = true;
            pnlMenuMinuman.Visible = false;
            pnlMenuPemesanan.Visible = false;
            pnlMenuTentang.Visible = false;
        }

        private void btnMinuman_Click(object sender, EventArgs e)
        {
            pnlbtn.Height = btnMinuman.Height;
            pnlbtn.Top = btnMinuman.Top;
            pnlMenuMakanan.Visible = false;
            pnlMenuMinuman.Visible = true;
            pnlMenuPemesanan.Visible = false;
            pnlMenuTentang.Visible = false;
        }

        private void btnPesanan_Click(object sender, EventArgs e)
        {
            pnlbtn.Height = btnPesanan.Height;
            pnlbtn.Top = btnPesanan.Top;
            pnlMenuMakanan.Visible = false;
            pnlMenuMinuman.Visible = false;
            pnlMenuPemesanan.Visible = true;
            pnlMenuTentang.Visible = false;
        }

        private void btnTentang_Click(object sender, EventArgs e)
        {
            pnlbtn.Height = btnTentang.Height;
            pnlbtn.Top = btnTentang.Top;
            pnlMenuMakanan.Visible = false;
            pnlMenuMinuman.Visible = false;
            pnlMenuPemesanan.Visible = false;
            pnlMenuTentang.Visible = true;
        }

        private void pnlMenuMakanan_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void pnlAtas_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlMenuTentang_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlKiri_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbmeja.Items.Add("1");
            cbmeja.Items.Add("2");
            cbmeja.Items.Add("3");
            cbmeja.Items.Add("4");
            cbmeja.Items.Add("5");
            cbmeja.Items.Add("6");
            cbmeja.Items.Add("7");
            cbmeja.Items.Add("8");
        }

        
     
        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void ayam_TextChanged(object sender, EventArgs e)
        {
            ayam.Text = "30000";
           
        }

        private void totalsemua_TextChanged(object sender, EventArgs e)
        {
            try
            {
                totalsemua.Text = (float.Parse(ttlmkn.Text) + float.Parse(ttlmnm.Text)).ToString();
            }
            catch
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int aym,sop,udang,capcay, total1,total2,total3,total4, na,nb,nc,nd,jml,jml1;
            na= Convert.ToInt32(n1.Value);
            aym = Convert.ToInt32(ayam.Text);
            total1 = na * aym;
            t1.Text = total1.ToString();
            nb = Convert.ToInt32(n2.Value);
            sop = Convert.ToInt32(sup.Text);
            total2 = nb * sop;
            t2.Text = total2.ToString();
            nc = Convert.ToInt32(n3.Value);
            udang = Convert.ToInt32(udg.Text);
            total3 = nc * udang;
            t3.Text = total3.ToString();
            nd = Convert.ToInt32(n4.Value);
            capcay = Convert.ToInt32(cap.Text);
            total4 = nd * capcay;
            t4.Text = total4.ToString();
            jml=total1+total2+total3+total4;
            ttlmkn.Text = jml.ToString();

            int et, km, kp, ed, total5, total6, total7, total8, ne, nf, ng, nh;
            ne = Convert.ToInt32(n5.Value);
            et = Convert.ToInt32(teh.Text);
            total5 = ne * et;
            t5.Text = total5.ToString();
            nf = Convert.ToInt32(n6.Value);
            km = Convert.ToInt32(klamud.Text);
            total6 = nf * km;
            t6.Text = total6.ToString();
            ng = Convert.ToInt32(n7.Value);
            kp = Convert.ToInt32(kopi.Text);
            total7 = ng * kp;
            t7.Text = total7.ToString();
            nh = Convert.ToInt32(n8.Value);
            ed = Convert.ToInt32(doger.Text);
            total8 = nh * ed;
            t8.Text = total8.ToString();
            jml1 = total1 + total2 + total3 + total4 + total5 + total6 + total7 + total8;
            totalsemua.Text = jml.ToString();
            MessageBox.Show("Pesanan berhasil ditambahkan");

            
        }

        private void sup_TextChanged(object sender, EventArgs e)
        {
            sup.Text = "38000";
        }

        private void udg_TextChanged(object sender, EventArgs e)
        {
            udg.Text = "12000";
        }

        private void cap_TextChanged(object sender, EventArgs e)
        {
            cap.Text = "16000";
        }

        private void tambahmnm_Click(object sender, EventArgs e)
        {
            int et, km, kp, ed, total5, total6, total7, total8, ne, nf, ng, nh,jml,jml1;
            ne = Convert.ToInt32(n5.Value);
            et = Convert.ToInt32(teh.Text);
            total5 = ne * et;
            t5.Text = total5.ToString();
            nf = Convert.ToInt32(n6.Value);
            km = Convert.ToInt32(klamud.Text);
            total6 = nf * km;
            t6.Text = total6.ToString();
            ng = Convert.ToInt32(n7.Value);
            kp = Convert.ToInt32(kopi.Text);
            total7 = ng * kp;
            t7.Text = total7.ToString();
            nh = Convert.ToInt32(n8.Value);
            ed = Convert.ToInt32(doger.Text);
            total8 = nh * ed;
            t8.Text = total8.ToString();
            jml=total5 + total6 + total7 + total8;
            ttlmnm.Text = jml.ToString();
            MessageBox.Show("Pesanan berhasil ditambahkan");

            int aym, sop, udang, capcay, total1, total2, total3, total4, na, nb, nc, nd;
            na = Convert.ToInt32(n1.Value);
            aym = Convert.ToInt32(ayam.Text);
            total1 = na * aym;
            t1.Text = total1.ToString();
            nb = Convert.ToInt32(n2.Value);
            sop = Convert.ToInt32(sup.Text);
            total2 = nb * sop;
            t2.Text = total2.ToString();
            nc = Convert.ToInt32(n3.Value);
            udang = Convert.ToInt32(udg.Text);
            total3 = nc * udang;
            t3.Text = total3.ToString();
            nd = Convert.ToInt32(n4.Value);
            capcay = Convert.ToInt32(cap.Text);
            total4 = nd * capcay;
            t4.Text = total4.ToString();
            
         
            jml1 = total1 + total2 + total3 + total4 + total5 + total6 + total7 + total8;
            totalsemua.Text = jml.ToString();

          
        }

        private void teh_TextChanged(object sender, EventArgs e)
        {
            teh.Text = "5000";
        }

        private void klamud_TextChanged(object sender, EventArgs e)
        {
            klamud.Text = "8000";
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            kopi.Text = "6000";
        }

        private void doger_TextChanged(object sender, EventArgs e)
        {
            doger.Text = "10000";
        }

      

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pnlMenuPemesanan_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ttlmkn_TextChanged(object sender, EventArgs e)
        {

            
        }

        private void ttlmnm_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnPesan_Click(object sender, EventArgs e)
        {
            string data = nama_pmsn.Text;
            int countError = 0;
            data = data.Trim();
            if(String.IsNullOrEmpty(data))
            {
                MessageBox.Show("Silahkan Isi Data Anda\nUntuk bagian harga makanan dan minuman akan otomatis terinput\nsetelah anda memilih makanan dan minuman\nkemudian tekan tombol tambah)");
            }
            else
            {
                MessageBox.Show("Terima Kasih Sudah Memesan\nPesanan Akan Segera Kami Siapkan:))");
                
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            nama_pmsn.Clear();
            ttlmkn.Clear();
            ttlmnm.Clear();
            totalsemua.Clear();
            bayar.Clear();
            kembalian.Clear();
            nama_pmsn.Focus();
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        
        private void bayar_Keypress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }

        private void bayar_TextChanged_1(object sender, EventArgs e)
        {
            if (bayar.Text == "" || bayar.Text == "")
            {
                bayar.Text = "0";
            }
            else
            {
                int a = Convert.ToInt32(bayar.Text);
                int b = Convert.ToInt32(totalsemua.Text);
                int kembali;
                kembali = a - b;
                kembalian.Text = Convert.ToString(kembali);
            }
        }
        
    }
}
