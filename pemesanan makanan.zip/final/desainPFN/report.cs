﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desainPFN
{
    public partial class report : Form
    {
        public report()
        {
            InitializeComponent();
        }

        private void report_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbrestoranDataSet1.tbl_transk' table. You can move, or remove it, as needed.
            this.tbl_transkTableAdapter.Fill(this.dbrestoranDataSet1.tbl_transk);
            // TODO: This line of code loads data into the 'dbrestoranDataSet.tbl_transaksi' table. You can move, or remove it, as needed.
            this.tbl_transaksiTableAdapter.Fill(this.dbrestoranDataSet.tbl_transaksi);

            this.reportViewer1.RefreshReport();
        }
    }
}
